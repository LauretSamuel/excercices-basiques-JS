
    
    function affichage_popup() {
        
        const avertissement = 'Ceci est un message d\'avertissement' 
        alert(avertissement )
        
        };
        
        
        function affichage_debug() {
            const debugguage = 'Ceci est un message qui permet le debugguage'
            alert(debugguage)
            
        };




      function wname() {
          
        let nom = prompt ('C\'est quoi ton ptit nom ?')
        alert('Votre nom est : '+nom+' ')

      }

        wname()