



function affichage_popup() {
        
    const avertissement = 'Ceci est un message d\'avertissement' 
    alert(avertissement )
    
    };
    
    
    function affichage_debug() {
        const debugguage = 'Ceci est un message qui permet le debugguage'
        alert(debugguage)
        
    };




  function wname() {
      
    var nom = prompt ('C\'est quoi ton ptit nom ?')
    alert('Votre nom est : '+nom+' ');
     
    
  }


  function wname2() {


    var nom = prompt ('C\'est quoi ton ptit nom ?')
    var prenom = prompt ('et ton prénom ?')
    alert ('ducoup tu t\'appelles : '+nom+ '  '+prenom+'')

      
  }
  
  function don_de_bille() {
      
    const sac = 14
    const ed = prompt ('Combien de bille voulez-vous ?')
    
    
    
    if (ed >14) {

        alert('Tu n\'es vraiment pas gentil, je ne peux pas t\'en donner autant')
        
        
        
    }

    else if (ed < 14) {


        var rest =( sac-ed)
        alert('D\'accord, tu m\'en a pris <'+ed+'> et il m\'en reste <'+rest+'>')

        
    }

   
  }






function contrôle_identite() {
    
    let age = prompt ('Bonjour quelle age avez vous ?')
    if (age<18) {
        alert('vous etes mineur')
        
    }

    else if (age>=18) {
    alert('vous etes majeur')}

}




function array () {
    
    let tab = ['naze', 'gamin', 'capron', 'attoumani', 'adbou', 'morel', 'cyprien', 'vellien', 'baret', 'lauret']
    console.log(tab)

    let tuveuxkoi = prompt ('Que voulez vous faire ? \n \n 1- Mettre le tableau dans l\'ordre \n \n 2- Inverser complètement le tableau')


    if (tuveuxkoi == 1) {
         
        tab.sort()
        console.log(tab)


    }

    else if (tuveuxkoi == 2){


        tab.reverse()
        console.log(tab)
}
    }
    
        
